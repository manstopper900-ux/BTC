1. Push this folder to GitHub, import into Vercel.
2. Vercel > Storage > Marketplace > Upstash Redis (adds KV_REST_API_* vars).
3. Add the env vars from .env.example (run `npx web-push generate-vapid-keys`).
4. Telegram: create a bot with @BotFather, message it, get your chat id from @userinfobot.
5. Vercel Hobby crons run once a day only. Create a free job on cron-job.org calling
   https://YOUR-APP.vercel.app/api/scan?key=CRON_SECRET every 5 minutes (or use Vercel Pro and edit vercel.json).
6. Open the site on your phone > Add to Home Screen > Enable phone alerts (iPhone needs iOS 16.4+ and the home-screen install).
7. Tap "Backtest last 30 days" on the dashboard (or open /api/backtest?days=60) to see win rate and drawdown from real history.
