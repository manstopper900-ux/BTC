import { candlesRange, backtest } from '@/lib/strategy';
export const dynamic='force-dynamic';
export const maxDuration=60;
export async function GET(req){
  const days=Math.min(Number(new URL(req.url).searchParams.get('days'))||30,60);
  const end=Math.floor(Date.now()/1000), start=end-days*86400;
  const [h1,m15]=await Promise.all([candlesRange(3600,start-12*86400,end),candlesRange(900,start-3*86400,end)]);
  return Response.json({days,...backtest(h1,m15)});
}
