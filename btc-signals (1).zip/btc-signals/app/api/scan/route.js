import { candles, evaluate, aiReview } from '@/lib/strategy';
import { R } from '@/lib/redis';
import { notify } from '@/lib/notify';
export const dynamic='force-dynamic';
export async function GET(req){
  const u=new URL(req.url);
  const ok=req.headers.get('authorization')===`Bearer ${process.env.CRON_SECRET}`||u.searchParams.get('key')===process.env.CRON_SECRET;
  if(!ok) return new Response('unauthorized',{status:401});
  const [h1,m15]=await Promise.all([candles(3600),candles(900)]);
  await R('SET','price',String(m15.at(-1).c));
  const s=evaluate(h1,m15);
  if(!s) return Response.json({signal:null});
  const key=`${s.side}-${s.time}`;
  if(await R('GET','last')===key) return Response.json({signal:'duplicate'});
  const ai=await aiReview(s,m15);
  if(!ai.approve) return Response.json({signal:'rejected by AI',note:ai.note});
  await R('SET','last',key);
  const f=n=>Math.round(n).toLocaleString();
  const full={...s,note:ai.note};
  await R('LPUSH','signals',JSON.stringify(full)); await R('LTRIM','signals',0,49);
  await notify(`BTC ${s.side} confirmed`,`Entry ${f(s.entry)}\nSL ${f(s.sl)}\nTP1 ${f(s.tp1)} | TP2 ${f(s.tp2)}\n${s.trend}. ${ai.note}`);
  return Response.json({signal:full});
}
