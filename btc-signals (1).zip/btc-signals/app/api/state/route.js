import { R } from '@/lib/redis';
export const dynamic='force-dynamic';
export async function GET(){
  const [price,sig]=await Promise.all([R('GET','price'),R('LRANGE','signals',0,19)]);
  return Response.json({price:Number(price)||null,signals:(sig||[]).map(x=>JSON.parse(x))});
}
