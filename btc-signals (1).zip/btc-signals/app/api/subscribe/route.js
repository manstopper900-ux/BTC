import { R } from '@/lib/redis';
export async function POST(req){await R('SADD','subs',JSON.stringify(await req.json()));return Response.json({ok:true})}
