export const metadata={title:'BTC Signals',manifest:'/manifest.json'};
export default function L({children}){return <html lang="en"><body style={{margin:0,background:'#0b0e14',color:'#e8ecf1',fontFamily:'system-ui,sans-serif'}}>{children}</body></html>}
