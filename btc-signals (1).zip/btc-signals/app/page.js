'use client';
import { useEffect, useState } from 'react';
const f=n=>Math.round(n).toLocaleString();
const b64=s=>{const p='='.repeat((4-s.length%4)%4),r=atob((s+p).replace(/-/g,'+').replace(/_/g,'/'));return Uint8Array.from([...r].map(c=>c.charCodeAt(0)))};
export default function Home(){
  const [d,setD]=useState({price:null,signals:[]}),[msg,setMsg]=useState(''),[bt,setBt]=useState(null),[busy,setBusy]=useState(false);
  async function runBt(){setBusy(true);setBt(null);try{setBt(await (await fetch('/api/backtest?days=30')).json())}catch{setBt({error:1})}setBusy(false)}
  useEffect(()=>{const g=()=>fetch('/api/state').then(r=>r.json()).then(setD);g();const i=setInterval(g,30000);return()=>clearInterval(i)},[]);
  async function enable(){
    try{
      if(await Notification.requestPermission()!=='granted') return setMsg('Permission denied');
      const reg=await navigator.serviceWorker.register('/sw.js');await navigator.serviceWorker.ready;
      const sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:b64(process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY)});
      await fetch('/api/subscribe',{method:'POST',body:JSON.stringify(sub)});setMsg('Alerts on ✅');
    }catch(e){setMsg('Failed: '+e.message)}
  }
  const s=d.signals[0],card={background:'#151a23',borderRadius:14,padding:16,marginBottom:12};
  return <main style={{maxWidth:520,margin:'0 auto',padding:16}}>
    <h2 style={{margin:'8px 0'}}>BTC Signals <span style={{float:'right',fontSize:16}}>{d.price&&'$'+f(d.price)}</span></h2>
    <button onClick={enable} style={{width:'100%',padding:12,borderRadius:12,border:0,background:'#f7931a',fontWeight:700,marginBottom:12}}>🔔 Enable phone alerts</button>
    {msg&&<p>{msg}</p>}
    <div style={card}>{s?<>
      <b style={{color:s.side==='BUY'?'#3ddc84':'#ff5c5c',fontSize:22}}>{s.side}</b> <small>{new Date(s.time*1000).toLocaleString()}</small>
      <p>Entry <b>{f(s.entry)}</b><br/>Stop loss <b>{f(s.sl)}</b><br/>TP1 <b>{f(s.tp1)}</b> · TP2 <b>{f(s.tp2)}</b></p>
      <small>{s.trend} · RSI {s.rsi} · {s.note}</small></>:<span>No confirmed setup. Waiting — no random trades.</span>}</div>
    <iframe title="chart" src="https://s.tradingview.com/widgetembed/?symbol=COINBASE:BTCUSD&interval=15&theme=dark" style={{width:'100%',height:340,border:0,borderRadius:14}}/>
    <button onClick={runBt} disabled={busy} style={{width:'100%',padding:12,borderRadius:12,border:'1px solid #333',background:'#151a23',color:'#e8ecf1',margin:'12px 0'}}>{busy?'Running… (up to 1 min)':'📊 Backtest last 30 days'}</button>
    {bt&&(bt.error?<p>Backtest failed, try again.</p>:<div style={card}><b>{bt.trades} trades · {bt.winRate}% win rate</b><br/>Net {bt.totalR>0?'+':''}{bt.totalR}R · max drawdown {bt.maxDrawdownR}R<br/><small>Win = TP1 hit before SL. At 1.5R, you break even at ~40% wins. AI filter not included, so live results can differ.</small></div>)}
    <h4>History</h4>{d.signals.slice(1).map(x=><div key={x.time+x.side} style={{...card,padding:10,fontSize:14}}>{x.side} @ {f(x.entry)} · SL {f(x.sl)} · TP {f(x.tp1)}/{f(x.tp2)}</div>)}
    <p style={{opacity:.5,fontSize:12}}>Signals aren't financial advice. Always use stop losses.</p>
  </main>
}
